import * as cheerio from "cheerio";
import puppeteer from "puppeteer";
import type { WebsiteData } from "./gemini";

// User-friendly error messages for HTTP status codes
function getHttpErrorMessage(statusCode: number, url: string): string {
  const domain = new URL(url).hostname;
  
  switch (statusCode) {
    case 400:
      return `Bad Request (400): The website "${domain}" couldn't process our analysis request. This might be a temporary issue - please try again later.`;
    case 401:
      return `Authentication Required (401): The website "${domain}" requires authentication to access. This content is behind a login wall and cannot be analyzed.`;
    case 403:
      return `Access Forbidden (403): The website "${domain}" has advanced bot protection (likely Cloudflare or Akamai) that blocks automated analysis. This is common with large e-commerce sites. Unfortunately, our AEO analysis requires direct content access which isn't possible for heavily protected sites.`;
    case 404:
      return `Page Not Found (404): The webpage "${url}" doesn't exist or has been moved. Please check the URL and try again.`;
    case 429:
      return `Rate Limited (429): The website "${domain}" is temporarily blocking requests due to high traffic. Please wait a few minutes and try again.`;
    case 500:
      return `Server Error (500): The website "${domain}" is experiencing technical difficulties. This is an issue on their end - please try again later.`;
    case 502:
      return `Bad Gateway (502): The website "${domain}" is temporarily unavailable due to server issues. Please try again in a few minutes.`;
    case 503:
      return `Service Unavailable (503): The website "${domain}" is temporarily down for maintenance. Please try again later.`;
    case 504:
      return `Gateway Timeout (504): The website "${domain}" is taking too long to respond. This might be due to heavy server load - please try again.`;
    case 521:
      return `Web Server Down (521): The website "${domain}" appears to be offline. Please try again later.`;
    case 522:
      return `Connection Timeout (522): Unable to connect to "${domain}". The website may be experiencing connectivity issues.`;
    case 523:
      return `Origin Unreachable (523): The website "${domain}" is currently unreachable. This is likely a temporary network issue.`;
    case 524:
      return `Timeout (524): The website "${domain}" took too long to respond. Please try again in a few minutes.`;
    default:
      return `HTTP Error (${statusCode}): The website "${domain}" returned an unexpected error. Please try again later or contact support if the issue persists.`;
  }
}

// Environment detection
const isProduction = process.env.NODE_ENV === 'production';
const isReplit = process.env.REPLIT_DB_URL || process.env.REPL_ID;

/**
 * ANTI-BOT DETECTION SYSTEM
 * Implements sophisticated evasion strategies to bypass bot detection mechanisms
 * 
 * RATE LIMITING STRATEGY:
 * - Domain-based throttling prevents overwhelming target servers
 * - Maximum 3 requests per domain per minute (respectful crawling)
 * - Minimum 2-second intervals between requests to same domain
 * - Request history cleanup removes entries older than 1 minute
 * 
 * DETECTION AVOIDANCE:
 * - Mimics human browsing patterns with realistic request timing
 * - Prevents IP blacklisting through controlled request frequency
 * - Respects server resources while ensuring analysis completion
 */
const requestHistory = new Map<string, number[]>();
const MAX_REQUESTS_PER_DOMAIN = 3;
const MIN_REQUEST_INTERVAL = 2000; // 2 seconds between requests
const sessionPersistence = new Map<string, string>(); // Simple session storage

/**
 * THROTTLING ALGORITHM
 * Determines if a request should be delayed to avoid bot detection
 * 
 * @param url - Target URL for throttling analysis
 * @returns boolean - true if request should be throttled
 * 
 * LOGIC:
 * 1. Extract domain from URL for per-domain tracking
 * 2. Initialize domain history if first request
 * 3. Clean expired requests (>1 minute old) from history
 * 4. Check if domain has exceeded max requests (3/minute)
 * 5. Verify minimum interval (2s) since last request
 * 
 * ANTI-PATTERN DETECTION:
 * - Prevents rapid-fire requests that trigger bot detection
 * - Maintains natural request distribution over time
 * - Reduces likelihood of CAPTCHA challenges or IP blocking
 */
function shouldThrottleRequest(url: string): boolean {
  const domain = new URL(url).hostname;
  const now = Date.now();
  
  if (!requestHistory.has(domain)) {
    requestHistory.set(domain, []);
  }
  
  const domainHistory = requestHistory.get(domain)!;
  
  // Clean old entries (older than 1 minute) - sliding window approach
  const cutoff = now - 60000;
  const recentRequests = domainHistory.filter(time => time > cutoff);
  requestHistory.set(domain, recentRequests);
  
  // Check if we need to throttle - max requests per time window
  if (recentRequests.length >= MAX_REQUESTS_PER_DOMAIN) {
    return true;
  }
  
  // Check minimum interval - prevents burst requests
  const lastRequest = recentRequests[recentRequests.length - 1];
  if (lastRequest && (now - lastRequest) < MIN_REQUEST_INTERVAL) {
    return true;
  }
  
  return false;
}

function recordRequest(url: string) {
  const domain = new URL(url).hostname;
  if (!requestHistory.has(domain)) {
    requestHistory.set(domain, []);
  }
  requestHistory.get(domain)!.push(Date.now());
}

/**
 * BROWSER FINGERPRINT GENERATOR
 * Creates realistic browser fingerprints to evade bot detection systems
 * 
 * FINGERPRINTING STRATEGY:
 * - Randomizes device characteristics to appear as different users
 * - Simulates realistic browser capabilities and preferences
 * - Rotates geographic and device signatures for authenticity
 * 
 * EVASION TECHNIQUES:
 * - Geographic diversity: 4 major US timezones rotation
 * - Privacy variation: Random do-not-track preferences (50/50 split)
 * - Device capabilities: Realistic browser API availability simulation
 * - Canvas fingerprint: Unique but plausible rendering signatures
 * - Touch support: Mobile/desktop device simulation (30% mobile)
 * 
 * ANTI-DETECTION FEATURES:
 * - Avoids static fingerprints that can be easily identified as bots
 * - Maintains plausible browser capability combinations
 * - Generates entropy that matches real user distributions
 */
function generateBrowserFingerprint() {
  const randomSeed = Math.random().toString(36).substring(2, 15);
  return {
    // Geographic diversity for location-based bot detection evasion
    timezone: ['America/New_York', 'America/Los_Angeles', 'America/Chicago', 'America/Denver'][Math.floor(Math.random() * 4)],
    // Standard browser capabilities - always enabled for modern browsers
    cookiesEnabled: true,
    // Privacy-conscious users variation - 50/50 split realistic
    doNotTrack: Math.random() > 0.5 ? '1' : null,
    // Modern browser storage APIs - consistently available
    localStorage: true,
    sessionStorage: true,
    indexedDB: true,
    webGL: true,
    // Unique canvas fingerprint per session - prevents static detection
    canvas: randomSeed,
    audioContext: true,
    // Device type simulation - 30% mobile usage realistic
    touchSupport: Math.random() > 0.7
  };
}

export async function scrapeWebsite(url: string): Promise<WebsiteData> {
  const startTime = Date.now();
  
  try {
    console.log(`Starting scrape for: ${url}`);
    console.log(`Environment: NODE_ENV=${process.env.NODE_ENV}, Production=${isProduction}, Replit=${!!isReplit}`);
    
    // Enhanced URL validation
    let urlObj;
    try {
      urlObj = new URL(url);
      console.log(`Parsed URL - Protocol: ${urlObj.protocol}, Host: ${urlObj.hostname}, Path: ${urlObj.pathname}`);
    } catch (urlError) {
      throw new Error(`Invalid URL format: ${url}. Please provide a valid URL starting with http:// or https://`);
    }
    
    if (!['http:', 'https:'].includes(urlObj.protocol)) {
      throw new Error(`Unsupported protocol: ${urlObj.protocol}. Only HTTP and HTTPS are supported.`);
    }
    
    // Check if we should throttle this request
    if (shouldThrottleRequest(url)) {
      const domain = urlObj.hostname;
      await new Promise(resolve => setTimeout(resolve, MIN_REQUEST_INTERVAL));
      console.log(`Throttled request to ${domain} - waiting ${MIN_REQUEST_INTERVAL}ms`);
    }
    
    recordRequest(url);
    
    // Enhanced fetch with multiple retry strategies
    let content = '';
    let loadTime = 0;
    let needsJavaScript = false;
    let fetchSuccess = false;
    let finalUrl = url; // Track final URL after redirects
    
    // Track fallback attempts for comprehensive error reporting
    const fallbackAttempts: Array<{
      strategy: number;
      status?: number;
      error?: string;
      blocked?: boolean;
    }> = [];
    
    /**
     * PROGRESSIVE FALLBACK STRATEGY
     * Multi-tier approach to bypass different types of bot detection systems
     * 
     * STRATEGY PROGRESSION:
     * 1. Full Browser Simulation - Comprehensive Chrome headers with security features
     * 2. Mobile Browser - iPhone Safari simulation (many sites allow mobile)
     * 3. Firefox Browser - Alternative desktop browser headers  
     * 4. Googlebot Simulation - Search engine crawler (often whitelisted)
     * 5. Honest Bot - Transparent RevenueExperts identification
     * 6. Academic Bot - Research crawler (often allowed by organizations)
     * 7. Minimal Crawler - Basic headers for lightweight detection
     * 8. No Headers - Last resort for extremely restrictive environments
     * 
     * TIMEOUT STRATEGY:
     * - Shorter timeouts for aggressive strategies (8s for full browser simulation)
     * - Longer timeouts for simpler strategies (18s for minimal headers)
     * - Exception: No headers gets short timeout (5s) as last resort
     * 
     * DETECTION EVASION FEATURES:
     * - Modern Chrome User-Agent with current version numbers
     * - Complete Sec-Fetch headers to simulate real browser navigation
     * - Progressive header reduction to bypass different security levels
     * - Honest bot identification (Strategy 3) for transparency when stealth fails
     */
    const fetchStrategies = [
      // Strategy 1: Full Browser Simulation - Maximum stealth
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
          'Accept-Encoding': 'gzip, deflate, br',
          'Connection': 'keep-alive',
          'Upgrade-Insecure-Requests': '1',
          // Modern browser security headers - critical for stealth
          'Sec-Fetch-Dest': 'document',
          'Sec-Fetch-Mode': 'navigate', 
          'Sec-Fetch-Site': 'none',
          'Cache-Control': 'max-age=0'
        },
        timeout: 8000
      },
      // Strategy 2: Mobile Browser Simulation - Many sites allow mobile
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
          'Accept-Encoding': 'gzip, deflate, br',
          'Connection': 'keep-alive'
        },
        timeout: 12000
      },
      // Strategy 3: Alternative Desktop Browser - Firefox simulation
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
          'Accept-Encoding': 'gzip, deflate, br',
          'Connection': 'keep-alive',
          'Upgrade-Insecure-Requests': '1'
        },
        timeout: 12000
      },
      // Strategy 4: Googlebot Simulation - Many sites allow Google
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en'
        },
        timeout: 15000
      },
      // Strategy 5: Honest Bot Identification - Transparent crawling
      {
        headers: {
          'User-Agent': 'RevenueExpertsBot/1.0 (+https://revenueexperts.ai)',
          'Accept': 'text/html,application/xhtml+xml'
        },
        timeout: 15000
      },
      // Strategy 6: Academic/Research Bot - Often whitelisted
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; research-crawler/1.0; +https://academia.edu)',
          'Accept': 'text/html,application/xhtml+xml',
          'From': 'research@academia.edu'
        },
        timeout: 18000
      },
      // Strategy 7: Minimal Headers - Basic tool simulation
      {
        headers: {
          'User-Agent': 'curl/7.68.0'
        },
        timeout: 18000
      },
      // Strategy 8: No Headers - Last resort for extreme restrictions
      {
        headers: {},
        timeout: 5000
      }
    ];
    
    for (let i = 0; i < fetchStrategies.length; i++) {
      const strategy = fetchStrategies[i];
      let retryCount = 0;
      const maxRetries = 2;
      
      while (retryCount <= maxRetries) {
        try {
          console.log(`Trying fetch strategy ${i + 1}/${fetchStrategies.length} (attempt ${retryCount + 1}/${maxRetries + 1}) with timeout: ${strategy.timeout}ms`);
          
          const controller = new AbortController();
          const timeoutId = setTimeout(() => {
            console.log(`Fetch strategy ${i + 1} timed out after ${strategy.timeout}ms`);
            controller.abort();
          }, strategy.timeout);
          
          const fetchOptions: RequestInit = {
            headers: strategy.headers as HeadersInit,
            signal: controller.signal,
            redirect: 'follow' as RequestRedirect,
            // Add additional options for production environments
            ...(isProduction && {
              cache: 'no-cache' as RequestCache,
              mode: 'cors' as RequestMode
            })
          };
          
          const response = await fetch(url, fetchOptions);
          clearTimeout(timeoutId);
          
          // Track final URL after redirects
          finalUrl = response.url;
          console.log(`Response status: ${response.status} ${response.statusText}`);
          if (finalUrl !== url) {
            console.log(`Redirect detected: ${url} → ${finalUrl}`);
          }
          
          // Handle specific HTTP status codes with user-friendly messages
          if (!response.ok) {
            const errorMessage = getHttpErrorMessage(response.status, url);
            console.log(`HTTP error: ${response.status} - ${errorMessage}`);
            
            // Enhanced 403 bypass techniques - try additional approaches before giving up
            if (response.status === 403) {
              console.log(`Strategy ${i + 1} blocked with 403, attempting 403 bypass techniques...`);
              
              // Advanced 403 Bypass Attempt 1: Wait and retry with different timing
              if (retryCount === 0) {
                console.log(`403 Bypass: Waiting 3 seconds and retrying with modified headers...`);
                await new Promise(resolve => setTimeout(resolve, 3000));
                
                // Try with modified headers to appear more legitimate
                const bypassHeaders: Record<string, string> = {
                  ...strategy.headers,
                  'Cache-Control': 'no-cache',
                  'Pragma': 'no-cache',
                  'X-Forwarded-For': '8.8.8.8', // Simulate proxy
                  'X-Real-IP': '8.8.8.8'
                };
                
                // Remove undefined values
                Object.keys(bypassHeaders).forEach(key => {
                  if (bypassHeaders[key] === undefined) {
                    delete bypassHeaders[key];
                  }
                });
                
                try {
                  const bypassResponse = await fetch(url, {
                    ...fetchOptions,
                    headers: bypassHeaders
                  });
                  
                  if (bypassResponse.ok) {
                    console.log(`✅ 403 Bypass successful with modified headers!`);
                    content = await bypassResponse.text();
                    loadTime = Date.now() - startTime;
                    fetchSuccess = true;
                    break;
                  }
                } catch (bypassError) {
                  console.log(`403 Bypass with modified headers failed:`, (bypassError as Error).message);
                }
              }
              
              // Advanced 403 Bypass Attempt 2: Try robots.txt path first (often allowed)
              if (retryCount === 1) {
                const robotsUrl = new URL('/robots.txt', url).href;
                console.log(`403 Bypass: Attempting robots.txt access at ${robotsUrl}...`);
                
                try {
                  const robotsResponse = await fetch(robotsUrl, fetchOptions);
                  if (robotsResponse.ok) {
                    console.log(`✅ 403 Bypass: robots.txt accessible, site likely allows some crawling`);
                    // Try original URL again after "warming up" with robots.txt
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    
                    const warmupResponse = await fetch(url, fetchOptions);
                    if (warmupResponse.ok) {
                      console.log(`✅ 403 Bypass successful after robots.txt warmup!`);
                      content = await warmupResponse.text();
                      loadTime = Date.now() - startTime;
                      fetchSuccess = true;
                      break;
                    }
                  }
                } catch (robotsError) {
                  console.log(`403 Bypass robots.txt attempt failed:`, (robotsError as Error).message);
                }
              }
              
              fallbackAttempts.push({
                strategy: i + 1,
                status: response.status,
                blocked: true
              });
              // Continue to next strategy after bypass attempts
              break; // Exit retry loop for this strategy, try next strategy
            }
            
            if (response.status === 401 || response.status === 429) {
              console.log(`Strategy ${i + 1} blocked with ${response.status}, trying next strategy...`);
              fallbackAttempts.push({
                strategy: i + 1,
                status: response.status,
                blocked: true
              });
              // Continue to next strategy instead of throwing immediately
              break; // Exit retry loop for this strategy, try next strategy
            }
            
            // For other errors, continue to try next strategy
            if (retryCount < maxRetries) {
              retryCount++;
              await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
              continue;
            }
            throw new Error(errorMessage);
          }
          
          if (response.ok) {
            content = await response.text();
            loadTime = Date.now() - startTime;
            fetchSuccess = true;
            console.log(`Fetch successful, content length: ${content.length}`);
            
            // Validate content is actually HTML
            if (content.length > 0 && (content.includes('<html') || content.includes('<HTML') || content.includes('<!DOCTYPE'))) {
              // Check if this looks like a JavaScript-heavy site
              if (!isProduction || !isReplit) {
                if (content.includes('__NEXT_DATA__') || 
                    content.includes('react') || 
                    content.includes('_next/') ||
                    content.includes('Loading...') ||
                    content.match(/<div[^>]*id="__next"[^>]*><\/div>/)) {
                  needsJavaScript = true;
                }
              } else {
                // In production deployment, avoid Puppeteer entirely
                needsJavaScript = false;
              }
              break;
            } else {
              console.log('Invalid content received, trying next strategy');
              fetchSuccess = false;
              retryCount++;
              continue;
            }
          } else {
            console.log(`HTTP error: ${response.status} ${response.statusText}`);
            
            // Enhanced error handling for enterprise bot protection - log but continue to try other strategies first
            if (response.status === 429) {
              console.log(`Strategy ${i + 1}: Rate limited (429), will try other strategies before giving up`);
            }
            
            if (response.status === 403) {
              const domain = new URL(url).hostname;
              const serverHeader = response.headers.get('server');
              const cfRay = response.headers.get('cf-ray');
              
              if (cfRay || serverHeader?.includes('cloudflare')) {
                console.log(`Strategy ${i + 1}: Cloudflare protection detected, trying alternative strategies`);
              } else {
                console.log(`Strategy ${i + 1}: Access forbidden (403), trying other strategies`);
              }
            }
            
            if (retryCount < maxRetries) {
              retryCount++;
              await new Promise(resolve => setTimeout(resolve, 1000 * retryCount)); // Exponential backoff
              continue;
            }
            break;
          }
        } catch (error) {
          console.log(`Fetch strategy ${i + 1} failed (attempt ${retryCount + 1}):`, error);
          
          // Track this error for comprehensive reporting
          let errorType = 'unknown';
          if (error instanceof Error) {
            // Debug: Log detailed error information
            console.log(`DEBUG: Error message: "${error.message}"`);
            console.log(`DEBUG: Error cause:`, error.cause);
            
            if (error.name === 'AbortError') {
              console.log(`Strategy ${i + 1} timed out after ${strategy.timeout}ms`);
              errorType = 'timeout';
            } else if (error.message.includes('certificate') || error.message.includes('SSL') || error.message.includes('TLS')) {
              errorType = 'ssl';
              // For SSL errors, we should still throw immediately as other strategies won't help
              const domain = new URL(url).hostname;
              throw new Error(`SSL Certificate Error: The website "${domain}" has SSL certificate issues that prevent secure analysis. This is a website configuration problem. Please contact the website owner to fix their SSL certificate.`);
            } else if (error.message.includes('fetch')) {
              console.log(`Strategy ${i + 1} network error: ${error.message}`);
              
              // Check for DNS errors in the cause chain
              const hasDnsError = error.message.includes('ENOTFOUND') || error.message.includes('ECONNREFUSED') || 
                                 (error.cause && typeof error.cause === 'object' && 'message' in error.cause && 
                                  typeof error.cause.message === 'string' && (error.cause.message.includes('ENOTFOUND') || error.cause.message.includes('ECONNREFUSED')));
              
              if (hasDnsError) {
                console.log(`DEBUG: DNS/Connection error detected - throwing immediately`);
                errorType = 'dns_connection';
                const domain = new URL(url).hostname;
                throw new Error(`Website Unavailable: Cannot connect to "${domain}". The website may be down, the domain may not exist, or there may be network connectivity issues. Please check the URL and try again.`);
              } else {
                errorType = 'network';
              }
            } else if (error.message.includes('ENOTFOUND') || error.message.includes('ECONNREFUSED')) {
              console.log(`DEBUG: Direct DNS/Connection error detected - throwing immediately`);
              errorType = 'dns_connection';
              // For DNS/connection errors, we should throw immediately as other strategies won't help
              const domain = new URL(url).hostname;
              throw new Error(`Website Unavailable: Cannot connect to "${domain}". The website may be down, the domain may not exist, or there may be network connectivity issues. Please check the URL and try again.`);
            }
          }
          
          fallbackAttempts.push({
            strategy: i + 1,
            error: errorType
          });
          
          if (retryCount < maxRetries) {
            retryCount++;
            await new Promise(resolve => setTimeout(resolve, 1000 * retryCount)); // Exponential backoff
            continue;
          }
          break;
        }
      }
      
      if (fetchSuccess) break;
    }
    
    if (!fetchSuccess) {
      // All fetch strategies failed, provide diagnostic information
      const domain = new URL(url).hostname;
      const errorDetails = {
        url: url,
        domain: domain,
        environment: process.env.NODE_ENV || 'development',
        timestamp: new Date().toISOString(),
        strategies_tried: fetchStrategies.length,
        final_error: 'All fetch strategies failed'
      };
      
      console.log('Complete scraping failure details:', errorDetails);
      console.log(`FALLBACK SYSTEM EXHAUSTED: All ${fetchStrategies.length} strategies failed for ${domain}`);
      console.log('Fallback attempts:', fallbackAttempts);
      
      // Analyze what happened during fallback attempts
      const blockedStrategies = fallbackAttempts.filter(a => a.blocked).length;
      const timeoutStrategies = fallbackAttempts.filter(a => a.error === 'timeout').length;
      const networkStrategies = fallbackAttempts.filter(a => a.error === 'network').length;
      
      // Try to identify if this was an SSL issue by checking if domain is accessible on HTTP
      try {
        const httpUrl = url.replace('https://', 'http://');
        const quickCheck = await fetch(httpUrl, { 
          method: 'HEAD', 
          signal: AbortSignal.timeout(5000),
          redirect: 'manual'  // Don't follow redirects to avoid infinite loops
        });
        if (quickCheck.ok || quickCheck.status === 301 || quickCheck.status === 302) {
          throw new Error(`SSL Configuration Issue: The website "${domain}" is accessible via HTTP but has SSL certificate problems that prevent HTTPS access. This prevents secure analysis. Please contact the website owner to fix their SSL certificate configuration.`);
        }
      } catch (sslCheckError) {
        // Continue with comprehensive error analysis
      }
      
      // After ALL strategies failed, provide enhanced error messaging with comprehensive diagnostics
      let diagnosticInfo = '';
      if (blockedStrategies > 0) {
        diagnosticInfo += ` ${blockedStrategies} strategies returned access forbidden/blocked responses.`;
      }
      if (timeoutStrategies > 0) {
        diagnosticInfo += ` ${timeoutStrategies} strategies timed out.`;
      }
      if (networkStrategies > 0) {
        diagnosticInfo += ` ${networkStrategies} strategies had network errors.`;
      }
      
      if (domain.includes('.gov') || domain.includes('.mil')) {
        throw new Error(`Government Website Protection: "${domain}" is a government website with enhanced security that blocks automated analysis after trying all 8 fallback strategies.${diagnosticInfo} Government sites typically have strict bot protection policies that prevent external analysis tools from accessing their content.`);
      } else if (blockedStrategies >= 3) {
        throw new Error(`Advanced Bot Protection: "${domain}" actively blocked ${blockedStrategies} of our 8 fallback strategies, indicating sophisticated bot protection (likely Cloudflare, enterprise security, or similar).${diagnosticInfo} This is common for large enterprise websites with advanced security measures.`);
      } else if (timeoutStrategies >= 3) {
        throw new Error(`Website Performance Issues: "${domain}" failed to respond within timeout limits on ${timeoutStrategies} of our 8 fallback strategies.${diagnosticInfo} This could indicate server overload, slow performance, or network connectivity issues.`);
      } else {
        throw new Error(`Website Access Failed: Unable to connect to "${domain}" after exhausting all 8 fallback strategies (Chrome → Mobile → Firefox → Googlebot → Honest Bot → Academic → Minimal → No Headers).${diagnosticInfo} This could indicate: (1) Advanced bot protection, (2) Website down/maintenance, (3) Network issues, or (4) Domain problems. Please verify the URL and try again.`);
      }
    }
    
    // Skip Puppeteer entirely in production deployments to avoid Chrome dependency issues
    if (needsJavaScript && !isProduction && !isReplit) {
      console.log('Using headless browser for JavaScript-rendered content (development only)');
      
      try {
        const browser = await puppeteer.launch({
          headless: true,
          args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-gpu',
            '--window-size=1920,1080'
          ]
        });
        
        const page = await browser.newPage();
        
        // Enhanced anti-bot detection evasion with randomization
        const userAgents = [
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
          'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
        ];
        
        const viewports = [
          { width: 1920, height: 1080 },
          { width: 1366, height: 768 },
          { width: 1440, height: 900 },
          { width: 1536, height: 864 },
          { width: 1280, height: 720 }
        ];
        
        const randomUserAgent = userAgents[Math.floor(Math.random() * userAgents.length)];
        const randomViewport = viewports[Math.floor(Math.random() * viewports.length)];
        
        await page.setUserAgent(randomUserAgent);
        await page.setViewport(randomViewport);
        
        // Set realistic headers to avoid bot detection
        await page.setExtraHTTPHeaders({
          'Accept-Language': 'en-US,en;q=0.9',
          'Accept-Encoding': 'gzip, deflate, br',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Connection': 'keep-alive',
          'Upgrade-Insecure-Requests': '1',
          'Sec-Fetch-Dest': 'document',
          'Sec-Fetch-Mode': 'navigate',
          'Sec-Fetch-Site': 'none',
          'Sec-Fetch-User': '?1',
          'Cache-Control': 'max-age=0'
        });
        
        // Advanced stealth mode to avoid detection
        await page.evaluateOnNewDocument(() => {
          // Override webdriver detection
          Object.defineProperty(navigator, 'webdriver', {
            get: () => undefined,
          });
          
          // Remove automation markers
          delete (window as any).webdriver;
          delete (window as any).__webdriver_evaluate;
          delete (window as any).__selenium_evaluate;
          delete (window as any).__webdriver_script_function;
          delete (window as any).__webdriver_script_func;
          delete (window as any).__webdriver_script_fn;
          delete (window as any).__fxdriver_evaluate;
          delete (window as any).__driver_unwrapped;
          delete (window as any).__webdriver_unwrapped;
          delete (window as any).__driver_evaluate;
          delete (window as any).__selenium_unwrapped;
          delete (window as any).__fxdriver_unwrapped;
          
          // Add realistic navigator properties
          Object.defineProperty(navigator, 'languages', {
            get: () => ['en-US', 'en'],
          });
          
          // Mock realistic plugins
          Object.defineProperty(navigator, 'plugins', {
            get: () => ({
              length: 5,
              0: { name: 'Chrome PDF Plugin', description: 'Portable Document Format' },
              1: { name: 'Chromium PDF Plugin', description: 'Portable Document Format' },
              2: { name: 'Microsoft Edge PDF Plugin', description: 'Portable Document Format' },
              3: { name: 'WebKit built-in PDF', description: 'Portable Document Format' },
              4: { name: 'Chrome PDF Viewer', description: 'Portable Document Format' }
            }),
          });
          
          // Override automation detection
          (window as any).chrome = {
            runtime: {},
            loadTimes: () => ({}),
            csi: () => ({}),
            app: {}
          };
          
          // Mock permissions API
          const originalQuery = window.navigator.permissions.query;
          window.navigator.permissions.query = (parameters: PermissionDescriptor) => (
            (parameters as any).name === 'notifications' ?
              Promise.resolve({ 
                state: Notification.permission,
                name: 'notifications',
                onchange: null,
                addEventListener: () => {},
                removeEventListener: () => {},
                dispatchEvent: () => true
              } as PermissionStatus) :
              originalQuery(parameters)
          );
          
          // Add realistic screen properties
          Object.defineProperty(screen, 'availWidth', {
            get: () => window.innerWidth,
          });
          Object.defineProperty(screen, 'availHeight', {
            get: () => window.innerHeight,
          });
          
          // Mock hardware concurrency
          Object.defineProperty(navigator, 'hardwareConcurrency', {
            get: () => 8,
          });
          
          // Mock device memory
          Object.defineProperty(navigator, 'deviceMemory', {
            get: () => 8,
          });
          
          // Add realistic connection info
          Object.defineProperty(navigator, 'connection', {
            get: () => ({
              effectiveType: '4g',
              rtt: 50,
              downlink: 10,
              saveData: false
            }),
          });
        });
        
        // Add random delay to simulate human behavior
        await new Promise(resolve => setTimeout(resolve, Math.random() * 1000 + 500));
        
        await page.goto(url, { 
          waitUntil: 'networkidle2',
          timeout: 30000 
        });
        
        // Simulate human-like interactions
        await page.mouse.move(Math.random() * 100, Math.random() * 100);
        await new Promise(resolve => setTimeout(resolve, Math.random() * 1000 + 1000));
        
        // Scroll to simulate reading behavior
        await page.evaluate(() => {
          window.scrollTo(0, document.body.scrollHeight / 4);
        });
        await new Promise(resolve => setTimeout(resolve, 500));
        
        await page.evaluate(() => {
          window.scrollTo(0, document.body.scrollHeight / 2);
        });
        await new Promise(resolve => setTimeout(resolve, 500));
        
        await page.evaluate(() => {
          window.scrollTo(0, 0);
        });
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Enhanced JavaScript interrogation for all e-commerce sites
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        // Extract JavaScript-specific elements valuable for e-commerce analysis
        const jsData = await page.evaluate(() => {
          const data: any = {};
          
          // E-commerce platform detection
          data.ecommercePlatform = {
            shopify: !!(window as any).Shopify || !!document.querySelector('[data-shopify]'),
            woocommerce: !!(window as any).wc_add_to_cart_params || !!document.querySelector('.woocommerce'),
            magento: !!(window as any).Magento || !!document.querySelector('[data-mage-init]'),
            bigcommerce: !!(window as any).BigCommerce || !!document.querySelector('[data-bc-]'),
            prestashop: !!(window as any).prestashop || !!document.querySelector('.prestashop'),
            opencart: !!(window as any).getURLVar || !!document.querySelector('#cart'),
            squarespace: !!(window as any).Squarespace || !!document.querySelector('[data-squarespace-]'),
            webflow: !!(window as any).Webflow || !!document.querySelector('[data-w-]'),
            custom: false
          };
          
          // Analytics and tracking detection
          data.analytics = {
            googleAnalytics: !!(window as any).gtag || !!(window as any).ga,
            googleTagManager: !!(window as any).google_tag_manager,
            facebookPixel: !!(window as any).fbq,
            hotjar: !!(window as any).hj,
            mixpanel: !!(window as any).mixpanel,
            segment: !!(window as any).analytics,
            klaviyo: !!(window as any).klaviyo,
            mailchimp: !!(window as any).mc4wp,
            hubspot: !!(window as any)._hsq
          };
          
          // Customer experience tools
          data.customerTools = {
            liveChat: !!document.querySelector('[data-widget="chat"]') || 
                     !!document.querySelector('.chat-widget') ||
                     !!(window as any).Intercom || 
                     !!(window as any).tawk_API ||
                     !!(window as any).Zendesk ||
                     !!(window as any).LC_API,
            reviews: !!document.querySelector('.review, .rating, [data-rating]') ||
                    !!(window as any).yotpo ||
                    !!(window as any).Trustpilot,
            wishlist: !!document.querySelector('[data-wishlist]') ||
                     !!document.querySelector('.wishlist') ||
                     !!(window as any).wishlist,
            quickView: !!document.querySelector('[data-quick-view]') ||
                      !!document.querySelector('.quick-view'),
            compareProducts: !!document.querySelector('[data-compare]') ||
                           !!document.querySelector('.compare')
          };
          
          // Extract comprehensive product information
          data.productData = [];
          const productSelectors = [
            '.product-item, .product-card, .product-grid-item',
            '[data-product-id], [data-product], [itemtype*="Product"]',
            '.woocommerce-loop-product, .product-wrapper',
            '.shop-item, .item-product, .product-block'
          ];
          
          productSelectors.forEach(selector => {
            document.querySelectorAll(selector).forEach(el => {
              const productInfo: any = {};
              productInfo.id = el.getAttribute('data-product-id') || el.getAttribute('data-product');
              productInfo.name = el.querySelector('.product-name, .product-title, h2, h3, .item-title')?.textContent?.trim();
              productInfo.price = el.querySelector('.price, .product-price, [class*="price"], .cost')?.textContent?.trim();
              productInfo.currency = el.querySelector('.currency, [data-currency]')?.textContent?.trim();
              productInfo.availability = el.querySelector('.stock, .availability, [data-stock]')?.textContent?.trim();
              productInfo.sku = el.getAttribute('data-sku') || el.querySelector('[data-sku]')?.textContent?.trim();
              
              if (productInfo.name || productInfo.price) {
                data.productData.push(productInfo);
              }
            });
          });
          
          // Content management system detection
          data.cms = {
            wordpress: !!document.querySelector('link[href*="wp-content"]') ||
                      !!document.querySelector('script[src*="wp-content"]') ||
                      !!(window as any).wp,
            drupal: !!document.querySelector('[data-drupal-]') || !!(window as any).Drupal,
            joomla: !!(window as any).Joomla || !!document.querySelector('[data-joomla]'),
            typo3: !!(window as any).TYPO3 || !!document.querySelector('[data-typo3]')
          };
          
          // Extract JavaScript-rendered content that might be missed by static scraping
          data.dynamicContent = {
            testimonials: Array.from(document.querySelectorAll('.testimonial, .review, [data-testid="testimonial"], .customer-review')).map(el => ({
              text: el.textContent?.trim(),
              author: el.querySelector('.author, .reviewer, .name, .customer-name')?.textContent?.trim(),
              rating: el.querySelector('.rating, .stars, [data-rating]')?.textContent?.trim()
            })),
            
            categories: Array.from(document.querySelectorAll('.category, .product-category, [data-category]')).map(el => ({
              name: el.querySelector('h2, h3, .category-title, .cat-title')?.textContent?.trim(),
              productCount: el.querySelector('.count, .product-count')?.textContent?.trim()
            })),
            
            promotions: Array.from(document.querySelectorAll('.promo, .sale, .discount, .offer, [data-promo]')).map(el => ({
              title: el.querySelector('h2, h3, .promo-title')?.textContent?.trim(),
              description: el.querySelector('p, .description, .promo-text')?.textContent?.trim(),
              code: el.querySelector('.code, .promo-code')?.textContent?.trim()
            })),
            
            locations: Array.from(document.querySelectorAll('.location, .store-location, [data-location]')).map(el => ({
              name: el.querySelector('.location-name, h3, h4')?.textContent?.trim(),
              address: el.querySelector('.address, .location-address')?.textContent?.trim(),
              hours: el.querySelector('.hours, .store-hours')?.textContent?.trim(),
              phone: el.querySelector('.phone, .tel')?.textContent?.trim()
            }))
          };
          
          // Check for JavaScript frameworks that might affect SEO
          data.framework = {
            react: !!(window as any).React || !!document.querySelector('[data-reactroot]'),
            vue: !!(window as any).Vue || !!document.querySelector('[data-v-]'),
            angular: !!(window as any).angular || !!document.querySelector('[ng-app]'),
            nextjs: !!(window as any).__NEXT_DATA__,
            gatsby: !!(window as any).___gatsby
          };
          
          // Extract meta data that might be JavaScript-injected
          data.jsMetaData = {
            title: document.title,
            description: document.querySelector('meta[name="description"]')?.getAttribute('content'),
            keywords: document.querySelector('meta[name="keywords"]')?.getAttribute('content'),
            ogTitle: document.querySelector('meta[property="og:title"]')?.getAttribute('content'),
            ogDescription: document.querySelector('meta[property="og:description"]')?.getAttribute('content'),
            ogImage: document.querySelector('meta[property="og:image"]')?.getAttribute('content')
          };
          
          // Check for lazy loading and dynamic content
          data.hasLazyLoading = !!document.querySelector('[data-lazy], [loading="lazy"]');
          data.hasInfiniteScroll = !!(window as any).IntersectionObserver && 
                                  !!document.querySelector('[data-infinite-scroll]');
          
          return data;
        });
        
        content = await page.content();
        loadTime = Date.now() - startTime;
        
        await browser.close();
        
        // Store the JavaScript data for later use in analysis
        (content as any).jsData = jsData;
      } catch (puppeteerError) {
        console.log('Puppeteer failed, using fetch content:', puppeteerError);
        // Content already available from fetch
      }
    } else if (needsJavaScript) {
      console.log('JavaScript-heavy site detected, but using fetch content in production environment');
      // Use the fetch content even for JS-heavy sites in production
    }
    
    const $ = cheerio.load(content);

    // Extract basic page information
    const title = $('title').text() || '';
    const metaDescription = $('meta[name="description"]').attr('content') || '';
    
    // Extract structured data
    const structuredData: any[] = [];
    $('script[type="application/ld+json"]').each((_, element) => {
      try {
        const jsonData = JSON.parse($(element).html() || '{}');
        structuredData.push(jsonData);
      } catch (e) {
        // Invalid JSON, skip
      }
    });

    // Extract headers (only available if we used fetch)
    const headers: Record<string, string> = {};
    if (!needsJavaScript) {
      // Headers are only available from fetch response
      headers['content-type'] = 'text/html';
    }

    // Extract links
    const links: string[] = [];
    $('a[href]').each((_, element) => {
      const href = $(element).attr('href');
      if (href) {
        links.push(href);
      }
    });

    // Extract images
    const images: string[] = [];
    $('img[src]').each((_, element) => {
      const src = $(element).attr('src');
      if (src) {
        images.push(src);
      }
    });

    // Get robots.txt
    let robotsTxt = '';
    try {
      const robotsUrl = new URL('/robots.txt', finalUrl).href;
      const robotsController = new AbortController();
      const robotsTimeoutId = setTimeout(() => robotsController.abort(), 10000);
      
      const robotsResponse = await fetch(robotsUrl, { signal: robotsController.signal });
      clearTimeout(robotsTimeoutId);
      
      if (robotsResponse.ok) {
        robotsTxt = await robotsResponse.text();
      }
    } catch (e) {
      // robots.txt not found or error, continue
    }

    // Check technical aspects
    const isHttps = finalUrl.startsWith('https://');
    const hasMobileViewport = $('meta[name="viewport"]').length > 0;
    const pageSize = Buffer.byteLength(content, 'utf8');

    // Extract visible text content with multiple fallback strategies
    let textContent = '';
    
    // Strategy 1: Try to get text from main content areas
    const contentSelectors = [
      'main', 'article', '#content', '.content', '#main', '.main',
      '.post-content', '.entry-content', '.page-content', '.content-wrapper',
      '.site-content', '.primary-content', '.main-content', 'body'
    ];
    
    for (const selector of contentSelectors) {
      const selectorContent = $(selector).text().replace(/\s+/g, ' ').trim();
      if (selectorContent.length > textContent.length) {
        textContent = selectorContent;
      }
    }
    
    // Strategy 2: If still no content, extract from visible elements
    if (textContent.length < 100) {
      // Remove script and style elements first
      $('script, style, noscript').remove();
      
      // Get text from paragraphs, headings, and divs
      const fallbackContent = $('p, h1, h2, h3, h4, h5, h6, div').text().replace(/\s+/g, ' ').trim();
      if (fallbackContent.length > textContent.length) {
        textContent = fallbackContent;
      }
    }
    
    // Strategy 3: If still minimal content, get all text but filter out common noise
    if (textContent.length < 50) {
      const allText = $('body').text().replace(/\s+/g, ' ').trim();
      // Filter out common WordPress/JS noise
      const filteredText = allText
        .replace(/Skip to content/gi, '')
        .replace(/Loading\.\.\./gi, '')
        .replace(/Menu/gi, '')
        .replace(/\s+/g, ' ')
        .trim();
      
      if (filteredText.length > textContent.length) {
        textContent = filteredText;
      }
    }
    
    // Log what we extracted for debugging
    console.log(`Content extraction result: ${textContent.length} characters extracted`);

    const websiteData: WebsiteData = {
      url: finalUrl, // Use final URL after redirects for consistent analysis
      title,
      metaDescription,
      content: textContent,
      structuredData,
      headers,
      links: links.slice(0, 100), // Limit to first 100 links
      images: images.slice(0, 50), // Limit to first 50 images
      robotsTxt,
      isHttps,
      hasMobileViewport,
      pageSize,
      loadTime
    };

    return websiteData;
  } catch (error) {
    throw new Error(`Failed to scrape website: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}
